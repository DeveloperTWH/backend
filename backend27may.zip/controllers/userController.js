const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const {
    sendOtpEmail,
    sendWelcomeEmail,
    sendPasswordResetOtpEmail,
} = require('../utils/mailer');
const {
    getCookieOptions,
    clearCookie,
    setAuthCookies,
    clearAuthCookies,
} = require('../utils/cookieHelper');

function getSafePublicRole(role) {
    return role === 'business_owner' ? 'business_owner' : 'customer';
}

exports.registerUser = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
        const { name, email, password, role, mobile, gender, minorityType } = req.body;
        const safeRole = getSafePublicRole(role);

        const existingUser = await User.findOne({ $or: [{ email }, { mobile }] });
        if (existingUser) {
            return res.status(400).json({
                success: false,
                message: 'User already exists with email or mobile',
            });
        }

        const passwordHash = await bcrypt.hash(password, 12);
        const otp = Math.floor(100000 + Math.random() * 900000).toString();
        const otpHash = await bcrypt.hash(otp, 10);
        const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

        const newUser = new User({
            name,
            email,
            passwordHash,
            mobile,
            role: safeRole,
            gender,
            minorityType,
            otp: otpHash,
            otpExpiry,
            isOtpVerified: false,
        });

        await newUser.save();

        try {
            await sendOtpEmail(email, otp);
        } catch (emailError) {
            console.error('Failed to send OTP email:', emailError);
        }

        res.cookie('otpPending', 'true', getCookieOptions(10 * 60 * 1000));

        return res.status(201).json({
            success: true,
            message: 'User registered successfully. OTP sent to mobile.',
        });
    } catch (err) {
        console.error('Registration error:', err);
        return res.status(500).json({ success: false, message: 'Server error' });
    }
};

exports.verifyOtp = async (req, res) => {
    const { email, otp } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user || !user.otp || !user.otpExpiry) {
            return res.status(400).json({
                success: false,
                message: 'OTP not generated or user not found',
            });
        }

        if (user.isDeleted) {
            return res.status(403).json({ success: false, message: 'Account has been deleted' });
        }

        if (user.isBlocked) {
            return res.status(403).json({ success: false, message: 'Account is blocked by admin' });
        }

        if (user.otpExpiry < Date.now()) {
            return res.status(400).json({ success: false, message: 'OTP has expired' });
        }

        const isValid = await bcrypt.compare(otp, user.otp);
        if (!isValid) {
            return res.status(400).json({ success: false, message: 'Invalid OTP' });
        }

        user.isOtpVerified = true;
        user.otp = undefined;
        user.otpExpiry = undefined;
        await user.save();

        try {
            const firstName = user.name.split(' ')[0];
            await sendWelcomeEmail(user.email, firstName, user.role);
        } catch (emailError) {
            console.error('Failed to send welcome email:', emailError);
        }

        const token = jwt.sign(
            { userId: user._id, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: '7d' }
        );

        setAuthCookies(res, token, user, 7 * 24 * 60 * 60 * 1000);
        clearCookie(res, 'otpPending');

        return res.status(200).json({
            success: true,
            message: 'OTP verified and login successful',
            token,
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                mobile: user.mobile,
                role: user.role,
                gender: user.gender,
            },
        });
    } catch (err) {
        console.error('OTP verify error:', err);
        return res.status(500).json({ success: false, message: 'Server error' });
    }
};

exports.resendOtp = async (req, res) => {
    const { email } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        if (user.isDeleted) {
            return res.status(403).json({ success: false, message: 'Account has been deleted' });
        }

        if (user.isBlocked) {
            return res.status(403).json({ success: false, message: 'Account is blocked by admin' });
        }

        if (user.isOtpVerified) {
            return res.status(400).json({ success: false, message: 'User already verified' });
        }

        const otp = Math.floor(100000 + Math.random() * 900000).toString();
        const otpHash = await bcrypt.hash(otp, 10);
        const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

        user.otp = otpHash;
        user.otpExpiry = otpExpiry;
        await user.save();

        await sendOtpEmail(user.email, otp);
        res.cookie('otpPending', 'true', getCookieOptions(10 * 60 * 1000));

        return res.status(200).json({
            success: true,
            message: 'OTP resent successfully.',
        });
    } catch (err) {
        console.error('Resend OTP error:', err);
        return res.status(500).json({ success: false, message: 'Server error' });
    }
};

exports.forgotPassword = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { email } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        if (user.isDeleted) {
            return res.status(403).json({ success: false, message: 'Account has been deleted' });
        }

        if (user.isBlocked) {
            return res.status(403).json({ success: false, message: 'Account is blocked by admin' });
        }

        if (!user.passwordHash) {
            return res.status(400).json({
                success: false,
                message: 'Password reset is not available for this account',
            });
        }

        const otp = Math.floor(100000 + Math.random() * 900000).toString();
        const otpHash = await bcrypt.hash(otp, 10);
        const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

        user.resetPasswordOtp = otpHash;
        user.resetPasswordOtpExpiry = otpExpiry;
        await user.save();

        try {
            await sendPasswordResetOtpEmail(user.email, otp);
        } catch (emailError) {
            console.error('Failed to send password reset OTP email:', emailError);
            return res.status(500).json({ success: false, message: 'Failed to send reset OTP' });
        }

        return res.status(200).json({
            success: true,
            message: 'Password reset OTP sent successfully.',
        });
    } catch (err) {
        console.error('Forgot password error:', err);
        return res.status(500).json({ success: false, message: 'Server error' });
    }
};

exports.resetPassword = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { email, otp, newPassword } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user || !user.resetPasswordOtp || !user.resetPasswordOtpExpiry) {
            return res.status(400).json({
                success: false,
                message: 'Invalid or expired reset request',
            });
        }

        if (user.isDeleted) {
            return res.status(403).json({ success: false, message: 'Account has been deleted' });
        }

        if (user.isBlocked) {
            return res.status(403).json({ success: false, message: 'Account is blocked by admin' });
        }

        if (user.resetPasswordOtpExpiry < Date.now()) {
            user.resetPasswordOtp = undefined;
            user.resetPasswordOtpExpiry = undefined;
            await user.save();

            return res.status(400).json({ success: false, message: 'Reset OTP has expired' });
        }

        const isValidOtp = await bcrypt.compare(otp, user.resetPasswordOtp);
        if (!isValidOtp) {
            return res.status(400).json({ success: false, message: 'Invalid reset OTP' });
        }

        user.passwordHash = await bcrypt.hash(newPassword, 12);
        user.resetPasswordOtp = undefined;
        user.resetPasswordOtpExpiry = undefined;
        await user.save();

        return res.status(200).json({
            success: true,
            message: 'Password reset successful',
        });
    } catch (err) {
        console.error('Reset password error:', err);
        return res.status(500).json({ success: false, message: 'Server error' });
    }
};

exports.loginUser = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
        const { email, password, role } = req.body;

        const user = await User.findOne({ email });
        if (!user || !user.passwordHash) {
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        }

        if (role && user.role !== role) {
            return res.status(401).json({ success: false, message: 'Invalid role for this account' });
        }

        if (user.isDeleted) {
            return res.status(403).json({ success: false, message: 'Account has been deleted' });
        }

        if (user.isBlocked) {
            return res.status(403).json({ success: false, message: 'Account is blocked by admin' });
        }

        const isMatch = await bcrypt.compare(password, user.passwordHash);
        if (!isMatch) {
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        }

        if (!user.isOtpVerified) {
            const otp = Math.floor(100000 + Math.random() * 900000).toString();
            const otpHash = await bcrypt.hash(otp, 10);
            const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

            user.otp = otpHash;
            user.otpExpiry = otpExpiry;
            await user.save();

            await sendOtpEmail(user.email, otp);
            res.cookie('otpPending', 'true', getCookieOptions(10 * 60 * 1000));

            return res.status(403).json({
                success: false,
                otpPending: true,
                message: 'OTP not verified. A new OTP has been sent.',
                user: {
                    email: user.email,
                    role: user.role,
                },
            });
        }

        const token = jwt.sign(
            { userId: user._id, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: '7d' }
        );

        setAuthCookies(res, token, user, 7 * 24 * 60 * 60 * 1000);

        return res.status(200).json({
            success: true,
            message: 'Login successful',
            token,
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                role: user.role,
                gender: user.gender,
            },
        });
    } catch (err) {
        console.error('Login error:', err);
        return res.status(500).json({ success: false, message: 'Server error' });
    }
};

exports.logout = (req, res) => {
    clearAuthCookies(res);
    clearCookie(res, 'otpPending');

    res.status(200).json({ message: 'Logged out successfully' });
};
